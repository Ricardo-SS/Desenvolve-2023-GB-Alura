const salaDePython = ['Melissa','Helena','Rodrigo']

const salaDeJavaScript = ['Ju','Leo','Raquel']

const salasUnificadas = salaDePython.concat(salaDeJavaScript)

console.log(salasUnificadas)