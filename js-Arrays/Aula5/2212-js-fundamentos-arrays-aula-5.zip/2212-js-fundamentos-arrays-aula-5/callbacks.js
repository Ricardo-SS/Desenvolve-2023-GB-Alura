const nomes = ["Ana","Ju","Leo","Paula"]

nomes.forEach(ImprimeNomes)

function ImprimeNomes(nome){
    console.log(nome)
}